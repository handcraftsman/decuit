Open the WatiN.sln file when using Visual Studio 2010

Open the WatiN.vs2008.sln file when using Visual Studio 2008